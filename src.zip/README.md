# cs3110-finalproject

We need something to add files to an index, where index would be placed 
inside a directory.
.ex_dir
---index
---init_state
---storage
